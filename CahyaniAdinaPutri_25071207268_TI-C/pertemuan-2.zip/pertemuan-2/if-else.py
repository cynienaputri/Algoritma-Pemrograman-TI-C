#python if 
a = 33
b = 200
if b > a:
  print("b is greater than a")

  #python elif
  a = 33
b = 33
if b > a:
  print("b is greater than a")
elif a == b:
  print("a and b are equal")

  #python else
  a = 200
b = 33
if b > a:
  print("b is greater than a")
elif a == b:
  print("a and b are equal")
else:
  print("a is greater than b")

  #shorthand if
  a = 2
b = 330
print("A") if a > b else print("B")